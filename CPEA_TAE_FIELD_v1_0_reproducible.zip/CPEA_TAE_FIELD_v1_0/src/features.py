import numpy as np
from scipy.signal import hilbert
from scipy.stats import entropy
from sklearn.cluster import KMeans

def permutation_entropy(x, order=3, delay=1):
    x = np.asarray(x)
    n = len(x)-delay*(order-1)
    if n <= 0: return np.nan
    patterns = {}
    for i in range(n):
        w = x[i:i+delay*order:delay]
        key = tuple(np.argsort(w, kind="stable"))
        patterns[key] = patterns.get(key, 0)+1
    p = np.array(list(patterns.values()), float); p /= p.sum()
    return float(entropy(p, base=2))

def spectral_entropy(psd):
    p = np.asarray(psd,float)
    p /= p.sum(axis=-1, keepdims=True)+1e-12
    return float(np.mean(-np.sum(p*np.log2(p+1e-12), axis=-1)))

def phase_locking_value(x,y):
    phx, phy = np.angle(hilbert(x)), np.angle(hilbert(y))
    return float(np.abs(np.mean(np.exp(1j*(phx-phy)))))

def microstate_labels(epochs, n_states=4, random_state=0):
    X=[]
    for epoch in epochs:
        topo=epoch-epoch.mean(axis=0,keepdims=True)
        topo/=np.linalg.norm(topo,axis=0,keepdims=True)+1e-12
        X.append(topo.T)
    X=np.concatenate(X,axis=0)
    km=KMeans(n_clusters=n_states,random_state=random_state,n_init=20)
    return km.fit_predict(X), km.cluster_centers_

def transition_matrix(labels,n_states):
    T=np.zeros((n_states,n_states))
    for a,b in zip(labels[:-1],labels[1:]): T[a,b]+=1
    T/=T.sum(axis=1,keepdims=True)+1e-12
    return T

def js_divergence(P,Q):
    P=np.asarray(P,float)+1e-12; Q=np.asarray(Q,float)+1e-12
    P/=P.sum(); Q/=Q.sum(); M=.5*(P+Q)
    return .5*entropy(P,M,base=2)+.5*entropy(Q,M,base=2)
