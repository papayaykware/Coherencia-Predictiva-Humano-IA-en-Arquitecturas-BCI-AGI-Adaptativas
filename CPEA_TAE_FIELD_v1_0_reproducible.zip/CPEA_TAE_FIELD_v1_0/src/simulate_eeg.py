import numpy as np
import mne

SEED = 20261001

def make_simulated_raw(n_subjects=12, sfreq=250, duration=120, n_channels=16, seed=SEED):
    rng = np.random.default_rng(seed)
    ch_names = [f"EEG{i:02d}" for i in range(n_channels)]
    info = mne.create_info(ch_names, sfreq, ch_types="eeg")
    n_times = int(duration * sfreq)
    t = np.arange(n_times) / sfreq
    out = []
    for subj in range(n_subjects):
        data = 4e-6 * rng.standard_normal((n_channels, n_times))
        nets = [np.arange(0,4), np.arange(4,8), np.arange(8,12), np.arange(12,16)]
        freqs = [8.0, 10.0, 20.0, 6.0]
        for net, f in zip(nets, freqs):
            phase = rng.uniform(0, 2*np.pi)
            latent = 8e-6*np.sin(2*np.pi*f*t + phase)
            data[net] += latent
        labels = []
        for j, et in enumerate(np.arange(10, duration-5, 2.0)):
            idx = int(et*sfreq)
            width = int(0.4*sfreq)
            if j % 6 == 5:
                label = "meaningful_exception"
                pulse = np.sin(2*np.pi*14*t[:width])*15e-6
                data[:8, idx:idx+width] += pulse
                data[8:, idx:idx+width] -= 0.5*pulse
            elif j % 6 == 3:
                label = "irrelevant_exception"
                pulse = np.sin(2*np.pi*14*t[:width])*15e-6
                data[:, idx:idx+width] += pulse
            else:
                label = "predictable"
            labels.append((et, label))
        raw = mne.io.RawArray(data, info.copy(), verbose=False)
        out.append((subj, raw, labels))
    return out
