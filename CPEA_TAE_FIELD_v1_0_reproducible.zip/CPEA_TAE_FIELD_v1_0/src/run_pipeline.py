import sys
from pathlib import Path
import numpy as np, pandas as pd
ROOT=Path(__file__).resolve().parents[1]; sys.path.insert(0,str(ROOT))
from src.simulate_eeg import make_simulated_raw
from src.analysis import permutation_test_diff, bootstrap_ci

def main():
    data=make_simulated_raw(n_subjects=12)
    rng=np.random.default_rng(20261001); rows=[]
    for subj,raw,labels in data:
        for condition,mu,n in [
            ("baseline",.90,40),("predictable",1.00,10),
            ("irrelevant_exception",1.15,5),("meaningful_exception",1.65,5)]:
            for v in rng.normal(mu,.15 if condition=="baseline" else .20,n):
                rows.append({"subject":subj,"condition":condition,"IRP":v})
    df=pd.DataFrame(rows); df.to_csv(ROOT/"results"/"irp_simulated.csv",index=False)
    a=df.loc[df.condition=="meaningful_exception","IRP"].values
    b=df.loc[df.condition=="irrelevant_exception","IRP"].values
    diff,p=permutation_test_diff(a,b); ci=bootstrap_ci(a,b)
    pd.DataFrame([{"contrast":"meaningful - irrelevant","difference":diff,
                   "permutation_p":p,"CI_low":ci[0],"CI_high":ci[1]}]).to_csv(
                       ROOT/"results"/"primary_test.csv",index=False)
    print(f"Primary simulated contrast: {diff:.3f}; p={p:.5f}; 95% CI={ci[0]:.3f},{ci[1]:.3f}")

if __name__=="__main__": main()
