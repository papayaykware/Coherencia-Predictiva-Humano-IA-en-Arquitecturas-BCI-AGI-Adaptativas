import numpy as np

def irp_score(feature_vector, baseline_matrix):
    feature_vector=np.asarray(feature_vector,float)
    B=np.asarray(baseline_matrix,float)
    med=np.median(B,axis=0)
    mad=np.median(np.abs(B-med),axis=0)+1e-12
    z=(feature_vector-med)/(1.4826*mad)
    return float(np.mean(np.abs(z))), z

def permutation_test_diff(a,b,n_perm=10000,seed=20261001):
    rng=np.random.default_rng(seed); a=np.asarray(a); b=np.asarray(b)
    observed=np.mean(a)-np.mean(b); pooled=np.concatenate([a,b]); n=len(a)
    count=0
    for _ in range(n_perm):
        p=rng.permutation(pooled)
        if abs(np.mean(p[:n])-np.mean(p[n:]))>=abs(observed): count+=1
    return observed,(count+1)/(n_perm+1)

def bootstrap_ci(a,b,n_boot=5000,seed=20261001):
    rng=np.random.default_rng(seed); a=np.asarray(a); b=np.asarray(b)
    d=np.empty(n_boot)
    for i in range(n_boot):
        d[i]=rng.choice(a,len(a),True).mean()-rng.choice(b,len(b),True).mean()
    return np.quantile(d,[.025,.975])
