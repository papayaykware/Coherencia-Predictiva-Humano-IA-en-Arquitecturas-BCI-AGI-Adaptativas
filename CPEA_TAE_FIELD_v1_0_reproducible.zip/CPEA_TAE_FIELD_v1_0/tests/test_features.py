import numpy as np
from src.features import permutation_entropy,phase_locking_value,transition_matrix,js_divergence
def test_entropy(): assert permutation_entropy(np.sin(np.linspace(0,100,1000))) >= 0
def test_plv(): 
    x=np.sin(np.linspace(0,100,1000)); assert phase_locking_value(x,x)>.99
def test_transition(): assert np.allclose(transition_matrix(np.array([0,1,1,2,2,0,1]),3).sum(1),1)
def test_js(): assert js_divergence(np.eye(2),np.eye(2))<1e-10
